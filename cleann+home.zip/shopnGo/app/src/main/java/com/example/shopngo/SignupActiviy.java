package com.example.shopngo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignupActiviy extends AppCompatActivity {

    TextView name, email, password, phone, confirmpassword, login;
    Button signup;

    FirebaseAuth outh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        outh = FirebaseAuth.getInstance();

        name = findViewById(R.id.signupnametxt);
        email = findViewById(R.id.signupemailtxt);
        password = findViewById(R.id.signuppasswordtxt);
        confirmpassword = findViewById(R.id.signupconfirmpasswordtxt);
        phone = findViewById(R.id.signupphonetxt);
        login = findViewById(R.id.signuplogintxt);
        signup = findViewById(R.id.signupsignupbtn);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameString = name.getText().toString();
                String emailString = email.getText().toString();
                String passwordString = password.getText().toString();
                String confirmpasswordString = confirmpassword.getText().toString();
                String phoneString = phone.getText().toString();
                //
                if (!passwordString.equals(confirmpasswordString)) {
                    confirmpassword.setError("Password Does not Match");
                    return;
                }

                register(emailString, passwordString);
                Register_user_data(nameString, emailString, phoneString);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignupActiviy.this, LoginActivity.class));
            }
        });

    }

    private void register(String username, String password){
        outh.createUserWithEmailAndPassword(username, password).addOnCompleteListener(SignupActiviy.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(SignupActiviy.this, "Register User successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActiviy.this, QRCodeActivity.class));
                    finish();
                }else{
                    Toast.makeText(SignupActiviy.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void Register_user_data(String name, String email, String phone){
        String username = outh.getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference().child(username).child("name").setValue(name);
        FirebaseDatabase.getInstance().getReference().child(username).child("email").setValue(email);
        FirebaseDatabase.getInstance().getReference().child(username).child("phone").setValue(phone);
    }
}